  alert("Hello ma friend")
  alert("AHAHHAHAHAHA")
  alert("pogi nyo")